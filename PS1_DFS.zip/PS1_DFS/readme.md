This repository contains the Julia code for solving the model and various plots in DFS 1977. It also contains the LaTeX code required to build the final write up.

### Running the code

- Place your a and b matrix '.txt' files in `solve_model/input` directory
- Change terminal directory to `solve_model/code` and type `make`
